// Simple client-side logic for Derivative Grow demo
(function(){
  const rateInput = document.getElementById('rate');
  const dlInput = document.getElementById('dlAmount');
  const convertBtn = document.getElementById('convertBtn');
  const result = document.getElementById('result');
  const priceCanvas = document.getElementById('priceChart');
  const refreshChartBtn = document.getElementById('refreshChart');
  const tradeBtn = document.getElementById('tradeBtn');
  const actionSelect = document.getElementById('action');
  const tradeAmount = document.getElementById('tradeAmount');
  const tradeLog = document.getElementById('tradeLog');
  const orderbookBody = document.querySelector('#orderbook tbody');

  function formatIDR(n){ return 'IDR ' + Number(n).toLocaleString('id-ID'); }

  convertBtn.onclick = ()=> {
    const r = Number(rateInput.value||0);
    const dl = Number(dlInput.value||0);
    result.textContent = formatIDR(r * dl);
  };

  // Mock price data
  function genPrices(n=40){
    let a = [];
    let p = 2400;
    for(let i=0;i<n;i++){
      p += (Math.random()-0.45)*80;
      a.push(Math.round(p));
    }
    return a;
  }

  function drawChart(data){
    const ctx = priceCanvas.getContext('2d');
    const w = priceCanvas.width;
    const h = priceCanvas.height;
    ctx.clearRect(0,0,w,h);
    // background grid
    ctx.globalAlpha=0.05;
    for(let i=0;i<5;i++){
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, i*(h/5), w, 1);
    }
    ctx.globalAlpha=1;
    // line
    ctx.beginPath();
    data.forEach((v,i)=>{
      const x = (i/(data.length-1))*(w-10)+5;
      const min = Math.min(...data);
      const max = Math.max(...data);
      const y = h - ((v-min)/(max-min||1))*(h-10)-5;
      if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
    });
    ctx.strokeStyle='#34d399';
    ctx.lineWidth=2;
    ctx.stroke();
    // last price label
    const last = data[data.length-1];
    ctx.fillStyle='#cbd5e1';
    ctx.fillText('Last: '+last, 8, 14);
  }

  let prices = genPrices();
  drawChart(prices);

  refreshChartBtn.onclick = ()=> {
    prices = genPrices();
    drawChart(prices);
    populateOrderbook(prices);
  };

  // trade handling (demo only)
  tradeBtn.onclick = ()=>{
    const action = actionSelect.value;
    const amt = Number(tradeAmount.value||0);
    const rate = Number(rateInput.value||0);
    const time = new Date().toLocaleString();
    const line = document.createElement('div');
    line.textContent = `[${time}] ${action.toUpperCase()} ${amt} DL → ${formatIDR(amt*rate)}`;
    tradeLog.prepend(line);
  };

  function populateOrderbook(prices){
    orderbookBody.innerHTML = '';
    const last = prices[prices.length-1];
    for(let i=0;i<8;i++){
      const tr = document.createElement('tr');
      const type = i%2===0 ? 'Buy' : 'Sell';
      const dl = Math.round(1 + Math.random()*200);
      const price = Math.round(last + (Math.random()-0.5)*120);
      tr.innerHTML = `<td>${type}</td><td>${dl}</td><td>${price}</td>`;
      orderbookBody.appendChild(tr);
    }
  }

  populateOrderbook(prices);

  // init conversion display
  convertBtn.click();
})();