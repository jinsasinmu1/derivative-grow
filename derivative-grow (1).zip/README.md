# Derivative Grow — Static Demo

Ini adalah static website demo bernama **Derivative Grow** — layout dan fitur minimal untuk dit-deploy ke Vercel.

### Fitur
- Konversi DL → IDR (editable rate)
- Chart harga mock (canvas)
- Form Buy/Sell demo (log di client-side)
- Orderbook simulasi

### Deploy ke Vercel
1. Zip folder ini atau push ke GitHub.
2. Di Vercel, klik **New Project** → pilih repository (atau drag & drop folder).
3. Untuk static site, gunakan build command: *none* and output directory: `/` (Vercel akan mendeteksi `index.html`).

### Catatan
- Ini adalah demo **client-side only** — tidak ada backend / database.
- Untuk fitur nyata (riil orderbook, pembayaran, autentikasi), tambahkan backend dan security.

Enjoy!
