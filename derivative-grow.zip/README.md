# Derivative Grow 🚀

Website minimalis siap deploy ke Vercel.

## Cara Jalankan Lokal
```bash
npm install
npm run dev
```

## Deploy ke Vercel
1. Upload project ini ke GitHub.
2. Import ke Vercel.
3. Klik Deploy ✅
