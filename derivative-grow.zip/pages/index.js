export default function Home() {
  return (
    <div style={{textAlign:"center", padding:"50px"}}>
      <h1>🚀 Derivative Grow</h1>
      <p>Website ini sudah online di Vercel</p>
    </div>
  )
}
